// Bu ödevde dugum yapisini kullanmak icin olusturduğum struct Node ile "circular linklist" kullanildi.
//Bu linklisti secme amacim calan sarkida list sonunu basina kolayca dondurerek istenilen yere getirmekti.
//Ayni zamanda dinamik bir yapi olusturucak ve islevler gerceklesirken bir sinir bulunmayacak.
//Circular linklist ile istenilen deger referans alinan degerin yerine eklenip kendi konumunu silinme islevi daha rahatbir şekilde gerçeklestirmemi sagladi.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int a;
FILE *dosya;
int SayiKontrol = 0;
char SecilenSarki[40] = "";
struct Node {
    char SarkiIsim[40];
    struct Node* next;
};
typedef struct Node node;
node * head = NULL ;

void Yazdirma(node *h) {
    if(h != NULL) { //list kontrolu
    node * gezici= h;
   // printf("%s\n",gezici->SarkiIsim);
    char Gecici[50];
    strcpy(Gecici,gezici->SarkiIsim);
    strcat(Gecici,"\n");
    DosyayaYazdir(Gecici);
    gezici = gezici-> next;                    //bos kontrolünden gecince yazdirma
    while(gezici != h) {
        //printf("%s\n" , gezici->SarkiIsim);
        char Gecici[50];
        strcpy(Gecici,gezici->SarkiIsim);
        strcat(Gecici,"\n");
        DosyayaYazdir(Gecici);
        gezici = gezici ->next;
    }
}
// printf("*****\n");
 char yazdirilacak[]= "*****\n";
 DosyayaYazdir(yazdirilacak);
//strcpy(yazdirilacak , gezici->SarkiIsim);

}

void SarkiSonaEkleme(node *h , char SarkiIsim[]) {
    if(h == NULL ){ // bos kontrolu
        h = (node*) malloc(sizeof(node));
        h->next = h;
        strcpy(h-> SarkiIsim,SarkiIsim);       //bossa olustur ekle
         head = h;
         SayiKontrol++;
            return;
    }
    else{                     // dögü kur
    node *gezici = h;
    while(gezici-> next != h) { //dairesel dongu oldugu icin nexti bastaysa ekle
        gezici= gezici->next;
    }
    gezici-> next = (node*)malloc(sizeof(node));
    strcpy( gezici->next-> SarkiIsim,SarkiIsim);

    gezici-> next -> next = h;
    SayiKontrol++;
    }
}
node* SarkiBasaEkleme(node *h , char SarkiIsim[]) { //basa eklenen sarki yeni head oldugu icin node dondur
     if(h == NULL ){ // bos kontrolu
        h = (node*) malloc(sizeof(node));
        h->next = h;
        strcpy(h-> SarkiIsim,SarkiIsim);
        SayiKontrol++;//list elemani 1 arttir
    return h;
    }
    else{
    node * Gecici = (node*)malloc(sizeof(node));
            strcpy(Gecici-> SarkiIsim , SarkiIsim);
            Gecici -> next = h;        //bas 'head' e ekleme
            node* gezici = h;
            while(gezici->next != h) {
                gezici = gezici -> next;
            }
            gezici -> next = Gecici;
            h = Gecici;
            SayiKontrol++;
    return h;
    }
}
node* SarkiMove(node* h, char SarkiIsim[] ,char referenceSarki[], char *yon){  //hareket ettirme
switch(*yon){//after before kontrolu
    case 'A'://after istenirse

        if(h!= NULL) {
         // node*iteratorSonBul= r;

            if(!strcmp(h->SarkiIsim,SarkiIsim)) {
                node * gezici = h;
                node *tasinacakNode=(node*)malloc(sizeof(node));
                tasinacakNode  = h;
                 while(gezici->next != h) {
                    gezici = gezici-> next;
                 }
                h = h->next;
                gezici-> next = h;
                node *ikincigezici = h;
                    while(ikincigezici->next != h && strcmp(ikincigezici->SarkiIsim,referenceSarki)) {
                       ikincigezici = ikincigezici -> next;
                    }
                tasinacakNode ->next = ikincigezici->next;
                ikincigezici-> next = tasinacakNode;
            return h;
            }

            else {
                node * ikincigezici = h;
                node *tasinacakNode=(node*)malloc(sizeof(node));
                while(ikincigezici -> next !=h && strcmp(ikincigezici-> next->SarkiIsim,SarkiIsim)) {
                    ikincigezici = ikincigezici -> next;
                }
                tasinacakNode = ikincigezici->next;
                ikincigezici-> next = ikincigezici->next ->next;
                node * gezici = h;
                while(gezici-> next != h && strcmp(gezici->SarkiIsim,referenceSarki) ) {
                    gezici = gezici -> next;
                }
                tasinacakNode ->next = gezici->next;
                gezici->next = tasinacakNode;
                strcpy(tasinacakNode -> SarkiIsim,SarkiIsim) ;
            return h;
            }
        }
    break;
    case 'B': //before istenirse

         if(h!= NULL) {
            if(!strcmp(h->SarkiIsim,SarkiIsim)) {
                    node * gezici = h;
                    node *tasinacakNode=(node*)malloc(sizeof(node));
                    tasinacakNode  = h;
                    while(gezici->next != h) {
                        gezici = gezici-> next;
                    }
                    h = h->next;
                   gezici-> next = h;

                   node *ikincigezici = h;
                    while(ikincigezici->next != h && strcmp(ikincigezici->next->SarkiIsim,referenceSarki)) {
                        ikincigezici = ikincigezici -> next;  //istenilen once ekleniyor ve eski yeri siliniyor
                    }
                    tasinacakNode ->next = ikincigezici->next;
                    ikincigezici-> next = tasinacakNode;
            return h;
            }
            else if(!strcmp(h->SarkiIsim,referenceSarki)) {
                    node * gezici = h;
                    node * SonBulucu = h;
                    node *tasinacakNode=(node*)malloc(sizeof(node));
                    while(gezici->next != h && strcmp(gezici->next ->SarkiIsim,SarkiIsim)){
                        gezici = gezici->next;
                    }
                    tasinacakNode = gezici->next;
                    gezici->next = gezici->next ->next;
                    while(SonBulucu->next != h) {
                        SonBulucu= SonBulucu-> next;
                    }
                    tasinacakNode ->next = h;
                     SonBulucu->next = tasinacakNode;
                        h= tasinacakNode;
                    return h;
            }
            else {
                node * ikincigezici = h;
            node *tasinacakNode=(node*)malloc(sizeof(node));
            while(ikincigezici -> next !=h && strcmp(ikincigezici-> next->SarkiIsim,SarkiIsim)) {
                ikincigezici = ikincigezici -> next;
            }
            tasinacakNode = ikincigezici->next;
            ikincigezici-> next = ikincigezici->next ->next;
            node * gezici = h;
            while(gezici-> next != h && strcmp(gezici->next->SarkiIsim,referenceSarki) ) {
            gezici = gezici -> next;
            }
            tasinacakNode ->next = gezici->next;
            gezici->next = tasinacakNode;
            strcpy(tasinacakNode -> SarkiIsim,SarkiIsim) ;
            return h;
            }
        }
     break;
    default:
        //print("kod hatasını düzelt yanliş alıyosun");
    break;
    }
}

void SarkiIlerletme(node* h, char *playKisim){
    //printf("\n%c sssssssssssssssssssssssss\n", playKisim);
     switch(*playKisim){
            case 'N':
                if(h!=NULL) {
                    if(!strcmp(SecilenSarki,"")) {
                        node * gezici = h;
                        strcpy(SecilenSarki,h->SarkiIsim);
                       // printf("Playing %s\n*****\n",SecilenSarki);
                        DosyayaYazdir("Playing\t");
                        char Gecici[50];
                        strcpy(Gecici,h->SarkiIsim);
                        DosyayaYazdir(Gecici);
                        DosyayaYazdir("\n*****\n");


                    }
                else{
                    node * SecilenSarkiIter = h;
                    while(SecilenSarkiIter->next != h && strcmp(SecilenSarkiIter->SarkiIsim,SecilenSarki) ) {
                        SecilenSarkiIter = SecilenSarkiIter->next;
                    }
                    strcpy(SecilenSarki,SecilenSarkiIter->next->SarkiIsim);
                    //printf("Playing %s\n*****\n",SecilenSarki);
                     DosyayaYazdir("Playing\t");
                        char GeciciY[50];
                        strcpy(GeciciY,SecilenSarkiIter->next->SarkiIsim);
                        DosyayaYazdir(GeciciY);
                        DosyayaYazdir("\n*****\n");
                    }
                }
            break;
            case 'P':
                if(h != NULL) {
                    if(!strcmp(SecilenSarki,"")) {
                        node * gezici = h;
                        while(gezici->next != h){
                            gezici = gezici->next;
                        }
                        strcpy(SecilenSarki,gezici->SarkiIsim);
                       // printf("Playing %s\n*****\n",SecilenSarki);
                        DosyayaYazdir("Playing\t");
                        char temp[50];
                        strcpy(temp,gezici->SarkiIsim);
                        DosyayaYazdir(temp);
                        DosyayaYazdir("\n*****\n");
                    }
                    else{
                        node * CalanSarki = h;
                        while(CalanSarki->next != h && strcmp(CalanSarki->next->SarkiIsim,SecilenSarki) ) {
                            CalanSarki = CalanSarki->next;
                        }

                        strcpy(SecilenSarki,CalanSarki->SarkiIsim);
                       // printf("Playing %s\n*****\n",SecilenSarki);
                        DosyayaYazdir("Playing\t");
                        char GeciciY[50];
                        strcpy(GeciciY,CalanSarki->SarkiIsim);
                        DosyayaYazdir(GeciciY);
                        DosyayaYazdir("\n*****\n");
                        }
                }
            break;
            default:
                //print("kod hatasını düzelt yanliş alıyosun");
            break;

   }
}

node* TerstenPlaylist(node *h) {
    if(h != NULL) { //listi terse cevirme fonksiyonu
        node *current,*prev,*next,*last;

    last = h;
    prev = h;
    current = h-> next;
    h = h->next;
    while(h !=last ) {
        h = h->next;
        current->next = prev;
        prev = current;
        current = h;
    }
    current-> next = prev;
    h= prev;
    return h;
    }
}
node *Silme(node *h, char SarkiIsim[]) {  //silme fonksiyonu
    if(h!=NULL){
        node *temp;
        node *gezici = h;
    if(!strcmp(h -> SarkiIsim,SarkiIsim)) {
            // head silersek ilk eleman yani
            if(strcmp(h->SarkiIsim,SecilenSarki)) {
                 while(gezici -> next != h) {
            gezici = gezici -> next;
        }
        gezici->next = h->next;
        free(h);
        SayiKontrol--;
        return gezici->next;
            }else {
               // printf("Cannot remove the playing song\n*****\n");
                DosyayaYazdir("Cannot Remove The Playing Song\n*****\n");
                SayiKontrol--;
                return h;
            }
    }
        while(gezici -> next != h && strcmp(gezici->next-> SarkiIsim,SarkiIsim) )  {
        gezici = gezici -> next;
        }
        if(strcmp(gezici->next,SecilenSarki)) {
            if(gezici -> next == h) {
               SayiKontrol--;
            return h;
        }
        temp = gezici -> next;
        gezici -> next = gezici -> next -> next;
        free(temp);
        SayiKontrol--;
        return h;
        }
        else {
           // printf("Cannot remove the playing song\n*****\n");
            DosyayaYazdir("Cannot Remove The Playing Song\n*****\n");
             return h;
        }
    }
}
void TotalOkuma() {
 if((dosya =fopen("input.txt","r+"))!= NULL) {
    while(!feof(dosya)) { //listi terse cevirme
            char * str;
            char arr[200];
        str = fgets(arr,200,dosya);
        char *ilkKisimReverse = strtok(str,"\n");
        if(!strcmp(ilkKisimReverse,"ReversePlaylist")) {
                if(head != NULL) {
                head =TerstenPlaylist(head);
                //bastir(head);
                //printf("revers girdi\n");
                }
        }
        else {
            char *ilkKisim  = strtok(str,"\t");

            if(!strcmp(ilkKisim,"InsertSong")) {
                    char *yon = malloc(50);
                    yon = strtok(NULL,"\t"); //SARKİ EKLEME
                    char *SarkiIsmi = malloc(50);
                    SarkiIsmi = strtok(NULL,"\n");
                     switch(*yon){
                        case 'T':
                            SarkiSonaEkleme(head,SarkiIsmi);//sona

                        break;
                        case 'H':
                            head = SarkiBasaEkleme(head,SarkiIsmi);//basa

                        break;
                        default:
                            //print("kod hatasını düzelt yanliş alıyosun");
                        break;

                    }

            }
             else if(!strcmp(ilkKisim,"MoveSong")) {
                    char *yon = malloc(50);//sarki yer degistirilmek istenirse
                    yon = strtok(NULL,"\t");
                    char *degisecekSarki = malloc(50);
                    degisecekSarki = strtok(NULL,"\t");
                    char *referansSarki = malloc(50);
                    referansSarki = strtok(NULL,"\n");
                    head = SarkiMove(head,degisecekSarki,referansSarki,yon);

            }
             else if(!strcmp(ilkKisim,"RemoveSong")) {
                    if(head != NULL ) {
                            if(SayiKontrol>0){   //sarki silinmek istenirse
                    char *SilinicekIsim = malloc(50);
                    SilinicekIsim = strtok(NULL,"\n");
                    head = Silme(head,SilinicekIsim);
                    }
                    }
            }
            else if(!strcmp(ilkKisim,"PlaySong")) {
                    char *playKisim = malloc(50);
                    playKisim = strtok(NULL,"\n");   //parcalanmada playsong denk gelince
                    if(head != NULL) {
                        if(SayiKontrol>0){
                           // printf("%c",*playKisim);
                            SarkiIlerletme(head,playKisim);
                        }
                    }
                    else {
                        //printf("No songs to play\n*****\n");
                        DosyayaYazdir("No Songs To Play\n*****\n");
                    }
                    //printf("%s: %s\n",ilkKisim,playKisim);
            }
            else if(!strcmp(ilkKisim,"PrintPlaylist")) {
                    char *playKisim = malloc(50);     //parcalanmada yazdirma denk gelince
                    playKisim = strtok(NULL,"\n");
                    if(head!=NULL ) {
                            if(SayiKontrol>0){
                            switch(*playKisim){
                        case'F':
                            Yazdirma(head);
                            break;
                        case'R':                           //burada tersten yazdirma fonksiyonu kullanmak yerine zaten
                            if(head != NULL) {            //reverse de buna ulasıldıgı için o fonksiyonla yazdirdim daha sonra listi eski haline getirdim
                                head = TerstenPlaylist(head);
                                Yazdirma(head);
                                head = TerstenPlaylist(head);
                            }
                            break;
                        default:
                            //print("kod hatasını düzelt yanliş alıyosun");
                            break;
                            }

                        }
                    }
                    else {
                       // printf("No songs to print\n*****\n");
                        DosyayaYazdir("No Songs To Print\n*****\n");

                    }
                }

            }
        }
    }

}
void DosyayaYazdir(char yazdiralacak[]){
    FILE * dosya;
    if((dosya=fopen("output.txt" , "a+"))!=NULL){  //bütün printf lenen degerler bu fonksiyona gonderiliyor
        fprintf(dosya , "%s" ,yazdiralacak );
    }
    fclose(dosya);
}

void satirHesapla() {
     if((dosya =fopen("input.txt","r+"))!= NULL) {
    while(!feof(dosya)) {
        char ch = fgetc(dosya); //input sayim dogru mu kontrolu
        if(ch=='\n') {
            a++;
        }
    }
     if(feof(dosya)) {
            fputs("\n",dosya);
        }
    }
    else{
       // printf("ulasmadik");
    }
        fclose(dosya);
}
int main()
{
    a= 0;
   satirHesapla();
    TotalOkuma();

    return 0;
}
